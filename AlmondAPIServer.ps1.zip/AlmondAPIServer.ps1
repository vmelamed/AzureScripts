Configuration AlmondAPIServer
{
    param ($MachineName)

    Node $MachineName
    {
        #Install the IIS Role
        WindowsFeature IIS
        {
            Name = "Web-Server"
            Ensure = "Present"
            IncludeAllSubFeature = $true
        }

        #Install ASP.NET 4.5
        WindowsFeature ASP
        {
            Name = "Web-Server"
            Ensure = "Present"
        }

        WindowsFeature WebApplicationInitialization
        {
            Name = "Web-AppInit"
            Ensure = "Present"
        }

        WindowsFeature WebDeployment
        {
            Name = "WDS-Deployment"
            Ensure = "Present"
        }

        WindowsFeature WcfHttpActivation
        {
            Name = "NET-WCF-HTTP-Activation"
            Ensure = "Present"
        }

        WindowsFeature WcfNetTcpActivation
        {
            Name = "NET-WCF-TCP-Activation"
            Ensure = "Present"
        }

        WindowsFeature WcfNamedPipeActivation
        {
            Name = "NET-WCF-PIPE-Activation"
            Ensure = "Present"
        }

        #Install the management console
        WindowsFeature WebServerManagementConsole
        {
            Name = "Web-Mgmt-Console"
            Ensure = "Present"
        }
    }
} 